<?php
/**
 * Plugin Name:       WP AMPlifier
 * Plugin URI:        http://markryancreative.com/wp-amplifier/
 * Description:       Instantly create brand-able Google AMP compliant posts and pages
 * Version:           1.6.2
 * Author: 			  Mark Ryan Creative 
 * Author URI: 		  http://www.markryancreative.com
 * Stable tag: 		  1.6.2
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

define('WP_AMPLIFIER_PRODUCT_ID', '627');
define('WP_AMPLIFIER_BASE_URL', 'http://markryancreative.com');
define('WP_AMPLIFIER_SECRET_KEY', 'h6zY5MF93TwCbxhTM8txCktnaGYtdmka');
define('WP_AMPLIFIER_PLUGIN_ROOT_PATH', plugin_dir_path( __FILE__ ));
define('WP_AMPLIFIER_PLUGIN_VERSION', "1.6.2");

function check_for_update(){
	require_once WP_AMPLIFIER_PLUGIN_ROOT_PATH . '/WPFDGitHubPluginUpdater.php';
	if ( is_admin() ) {
	    new WPFDGitHubPluginUpdater( __FILE__, 'markryancreative', "wpamplifier", "47980bbc582b8739fd58d91a1e3cb5b954b8eaf5" );
	}
}
add_action('admin_init', 'check_for_update');


function wp_amplifier_activate() {

	$wp_amplifier_page_settings = array(
		'logo_url' => '',
		'navigation_bar_color' => '#0a89c0',
		'amp_navigation_text_color' => '#FFFFFF',
		'amp_contact_details' => '',
		'amp_logo_width' => 80,
		'amp_logo_height' => 80,
		'amp_post_show_category' => true,
		'amp_post_show_author' => true,
		'amp_post_show_date' => true,
		'amp_page_show_author' => true,
		'amp_page_show_date' => true
	);

	update_option('wp_amplifier_page_settings', $wp_amplifier_page_settings);
	update_option('wp_amplifier_version', WP_AMPLIFIER_PLUGIN_VERSION);

}
register_activation_hook( __FILE__, 'wp_amplifier_activate' );


function wp_amplifier_page(){
	
	if(get_option('wp_amplifier_plugin_activated', 0) == 1){
		require_once WP_AMPLIFIER_PLUGIN_ROOT_PATH . '/admin/amp-settings.php';
	}
	else{
		require_once WP_AMPLIFIER_PLUGIN_ROOT_PATH . '/admin/activate.php';
	}

}

// add the WP AMPlifier menu to dashboard
function register_wp_amplifier_menu_page(){
	
	add_menu_page( 'WP AMPlifier', 
					'WP AMPlifier', 
					'manage_options', 
					'wp-amplifier',
					'wp_amplifier_page');
}
add_action( 'admin_menu', 'register_wp_amplifier_menu_page');


function wp_amplifier_activate_plugin(){
	$key = $_POST['activation_key'];
    $email = $_POST['activation_email'];

    $args = array(
        'request' => 'activation',
        'email' => $email,
        'product_id' => WP_AMPLIFIER_PRODUCT_ID,
        'secret_key' => WP_AMPLIFIER_SECRET_KEY,
        'licence_key' => $key
    );
    $base_url = add_query_arg('wc-api', 'software-api', WP_AMPLIFIER_BASE_URL);
    $url = $base_url . '&' . http_build_query($args);
    $response = wp_remote_get($url);

    $data = json_decode(wp_remote_retrieve_body($response), true);

    if (intval($data['code']) >= 100 && intval($data['code']) <= 105) {
        wp_send_json_error(array('message' => $data['error']));
    } 
    else {
        update_option('wp_amplifier_plugin_activated', 1);
        update_option('wp_amplifier_license_code', $key);
        update_option('wp_amplifier_activation_email', $email);
        wp_send_json_success();
    }
}
add_action('wp_ajax_wp_amplifier_activate_plugin', 'wp_amplifier_activate_plugin');

function amp_enqueue_styles() {
	wp_enqueue_style('spectrum', plugin_dir_url( __FILE__ ) . 'admin/js/spectrum.css');
}
add_action( 'admin_enqueue_scripts','amp_enqueue_styles' );

function amp_enqueue_scripts() {
	wp_enqueue_script('spectrum', plugin_dir_url( __FILE__ ) . 'admin/js/spectrum.js', array( 'jquery' ));
	wp_enqueue_script('jquery-parsley', plugin_dir_url( __FILE__ ) . 'admin/js/parsley.min.js', array( 'jquery' ));
	wp_enqueue_script('jquery-forms', plugin_dir_url( __FILE__ ) . 'admin/js/jquery.form.js', array( 'jquery' ));
	wp_enqueue_script( 'mark-amp', plugin_dir_url( __FILE__ ) . 'admin/js/wp-amplifier.js', array( 'jquery-forms' ));
}
add_action( 'admin_enqueue_scripts','amp_enqueue_scripts' );


if(get_option('wp_amplifier_plugin_activated', 0) == 0){
	return;
}

// include the core amp plugin
require_once( dirname( __FILE__ ) . '/amp/amp.php' );


add_filter( 'amp_post_template_file', 'wp_amplifier_set_custom_template', 10, 3 );

function wp_amplifier_set_custom_template( $file, $type, $post ) {
	if ( 'single' === $type ) {
		$file = dirname( __FILE__ ) . '/templates/wp-amplifier.php';
	}
	return $file;
}

/**
 * Set max width value for the content
 */ 
function wp_amplifier_change_content_width( $content_max_width ) {
	return 600;
}
add_filter( 'amp_content_max_width', 'wp_amplifier_change_content_width' );

/**
 * Save the WP AMPlifier settings
 */
function save_wp_amplifier_page_settings(){
	$navigation_bar_color = $_REQUEST['amp_navigation_color'];
	$amp_navigation_text_color = $_REQUEST['amp_navigation_text_color'];
	$amp_contact_details = $_REQUEST['amp_contact_details'];
	$amp_logo_width = $_REQUEST['amp_logo_width'];
	$amp_logo_height = $_REQUEST['amp_logo_height'];

	$amp_post_show_category = isset($_REQUEST['amp_post_show_category']) ? $_REQUEST['amp_post_show_category'] : false;
	$amp_post_show_author = isset($_REQUEST['amp_post_show_author']) ? $_REQUEST['amp_post_show_author'] : false;
	$amp_post_show_date = isset($_REQUEST['amp_post_show_date']) ? $_REQUEST['amp_post_show_date'] : false;
	$amp_page_show_author = isset($_REQUEST['amp_page_show_author']) ? $_REQUEST['amp_page_show_author'] : false;
	$amp_page_show_date = isset($_REQUEST['amp_page_show_date']) ? $_REQUEST['amp_page_show_date'] : false;

	$settings = get_option('wp_amplifier_page_settings');
	$amp_logo_url = $settings['logo_url'];
	if(isset($_FILES['amp_page_logo'])){
		$logo = $_FILES['amp_page_logo'];
		$content = @file_get_contents( $logo['tmp_name'] );
		$file = wp_upload_bits( $logo['name'], null, $content );
		$amp_logo_url = $file['url'];
	}
	$wp_amplifier_page_settings = array(
		'logo_url' => $amp_logo_url,
		'navigation_bar_color' => $navigation_bar_color,
		'amp_navigation_text_color' => $amp_navigation_text_color,
		'amp_contact_details' => $amp_contact_details,
		'amp_logo_width' => $amp_logo_width,
		'amp_logo_height' => $amp_logo_height,
		'amp_post_show_category' => $amp_post_show_category,
		'amp_post_show_author' => $amp_post_show_author,
		'amp_post_show_date' => $amp_post_show_date,
		'amp_page_show_author' => $amp_page_show_author,
		'amp_page_show_date' => $amp_page_show_date
	);

	update_option('wp_amplifier_page_settings', $wp_amplifier_page_settings);
	wp_send_json(array(
		'logo_url' => $wp_amplifier_page_settings['logo_url'],
		'width' => $amp_logo_width,
		'height' => $amp_logo_height
	));
}
add_action('wp_ajax_save_wp_amplifier_page_settings', 'save_wp_amplifier_page_settings');


/**
 * Add extra information to post template data
 */
function wp_amplifier_post_template_data($data, $post){
	$settings = get_option('wp_amplifier_page_settings', array());
	$data['post'] = $post;
	$data['site_icon_url'] = $settings['logo_url'];
	$data['navigation_bar_color'] = $settings['navigation_bar_color'];
	$data['amp_navigation_text_color'] = $settings['amp_navigation_text_color'];
	$data['amp_contact_details'] = $settings['amp_contact_details'];
	$data['amp_logo_width'] = $settings['amp_logo_width'];
	$data['amp_logo_height'] = $settings['amp_logo_height'];
	return $data;
}
add_filter('amp_post_template_data', 'wp_amplifier_post_template_data', 100, 2);


/*
 * Check for post meta settings
 */
function wp_amplifier_post_template_meta_parts($meta, $post){
	$settings = get_option('wp_amplifier_page_settings');

	$new_meta = array();
	$post_type = $post->post_type;
	switch($post_type){
		case 'post':
			if(true == $settings['amp_post_show_author']){
				$new_meta[] = 'meta-author';
			}
			if(true == $settings['amp_post_show_date']){
				$new_meta[] = 'meta-time';
			}
			if(true == $settings['amp_post_show_category']){
				$new_meta[] = 'meta-taxonomy';
			}
			break;
		case 'page':
			if(true == $settings['amp_page_show_author']){
				$new_meta[] = 'meta-author';
			}
			if(true == $settings['amp_page_show_date']){
				$new_meta[] = 'meta-time';
			}
			break;
	}
	return $new_meta;
}
add_filter('amp_post_template_meta_parts', 'wp_amplifier_post_template_meta_parts', 10, 2);

/**
 * add quick link to view AMP version of page
 */

function wp_amplifier_post_row_actions($actions, $post){
	$actions['amp'] = '<a target="_BLANK" href="'. get_permalink($post) .'amp">View AMP Page</a>';
	return $actions;
}
add_filter( 'post_row_actions', 'wp_amplifier_post_row_actions', 10, 2 );
add_filter( 'page_row_actions', 'wp_amplifier_post_row_actions', 10, 2 );

/** 
 * 
 */
function wp_amp_is_enabled($key){
	$settings = get_option('wp_amplifier_page_settings');
	$name = ' name="'. $key .'" ';
	return true == $settings[$key] ? $name . 'checked' : $name . '';
}