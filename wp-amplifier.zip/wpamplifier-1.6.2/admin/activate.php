<style>
  .parsley-errors-list li{
    color: red;
  }
</style>
<div class="outer-wrapper lightning-wp">
    <div class="header">
        <h1>WP AMPlifier- Activation</h1>
    </div>
    
    <div class="row">
        <div class="col s4 offset-s2">
            <div id="response-msg">
      
            </div>
            <form data-parsley-validate id="activation-form">
                <table class="form-table">
                    <tbody>
                       <tr>
                          <th scope="row" valign="top">Email-ID:</th>
                          <td>
                             <input required="true" placeholder="Enter activation email" 
                                   name="activation_email" id="activation_email" 
                                   data-parsley-required-message="Please enter activation email"
                                   type="text" class="validate regular-text" data-parsley-type="email" data-parsley-required="true">
                          </td>
                       </tr>
                       <tr>
                          <th scope="row" valign="top">Activation-Key:</th>
                          <td>
                            <input required="true" placeholder="Enter activation key" 
                       name="activation_key" id="activation_key" 
                       data-parsley-required-message="Please enter activation key"
                       type="text" class="validate regular-text" data-parsley-required="true">
                          </td>
                       </tr>
                       <tr>
                          <td>&nbsp;</td>
                          <td><button type="button" class="button button-primary waves-effect waves-light btn lactivate-plugin">Activate</button></td>
                       </tr>
                    </tbody>
                </table>
            </form>
        </div>
    </div>
</div>