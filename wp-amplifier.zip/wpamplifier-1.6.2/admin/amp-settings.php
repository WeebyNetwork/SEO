<style>
	.distance{
		margin-right:20px;
	}
	.disable-labels{
		margin-top:-5px;
	}
</style>
<h1>Amp Pages Settings!!</h1>
<hr>

<div class="response-msg"></div>
<?php $settings = get_option('wp_amplifier_page_settings'); ?>
<form method="POST" name="amp-settings-form" id="amp-settings-form">
	<table class="form-table">
		<tbody>
			<tr>
				<th scope="row">Choose Navigation Bar color:</th>
				<td>
					<input type='text' name="amp_navigation_color" 
							class="choose-color" value="<?php echo $settings['navigation_bar_color']; ?>" />
					<input type='hidden' name="amp_navigation_menu_color" class="" 
							value="<?php echo $settings['navigation_bar_color']; ?>" /> 
	            </td>
			</tr>
			<tr>
				<th scope="row">Choose Navigation Bar Text Color:</th>
				<td><input type='text' name="amp_navigation_text_color" class="choose-color" 
					value="<?php echo $settings['amp_navigation_text_color']; ?>"/>
	            </td>
			</tr>
			<tr>
				<th scope="row">Enter Contact Details:</th>
				<td><input required type="text" name="amp_contact_details" id="blogname" 
					class="regular-text" placeholder="Phone no or email address" 
					value="<?php echo $settings['amp_contact_details']; ?>"/>
	            </td>
			</tr>
			<tr>
				<th scope="row">Upload Logo:</th>
				<td>
					<?php 
						$display = $preview = '';
						if($settings['logo_url'] !== ''):
							$display = 'style="display:none"';
						else:
							$preview = 'style="display:none"';
						endif; ?>
						<div class="uploaded-amp-logo" <?php echo $preview ?>>
							<p class="description">Logo Preview:</p>
							<img src="<?php echo $settings['logo_url'] ?>" 
								width="<?php echo $settings['amp_logo_width']; ?>" 
								height="<?php echo $settings['amp_logo_height']; ?>" 
								class="site-icon" />
								<br>
							<a href="#" class="remove-amp-logo">Change</a>
						</div>
					
						<div class="upload-amp-logo" <?php echo $display ?>>
							<input parsley-filemaxsize="Upload|2" type="file" name="amp_page_logo" 
					          id="amp_page_logo" class="regular-text" />
					          <br>
					          <a href="#" class="cancel-amp-logo">Cancel</a>
						</div>
					
	            </td>
			</tr>
			<tr>
				<th scope="row">Logo Width:</th>
				<td>
					<input required type="number" name="amp_logo_width" class="regular-text" 
						value="<?php echo $settings['amp_logo_width']; ?>" placeholder="Ex: 80" />
					<p class="description">Logo width will be used in frontend</p>
	            </td>
			</tr>
			<tr>
				<th scope="row">Logo Height:</th>
				<td>
					<input required type="number" name="amp_logo_height" class="regular-text" 
						value="<?php echo $settings['amp_logo_height']; ?>" placeholder="Ex: 80" />
					<p class="description">Logo height will be used in frontend</p>
	            </td>
			</tr>
			<tr>
				<th scope="row"><br><br><br><div class="disable-labels">Show Author:</div></th>
				<td>

					<table class="table" width="18%">
						<tr>
							<td scope="row">
								<b>Posts</b><br><br>
								<div class="checkbox distance"><label>
									<input type="checkbox" <?php echo wp_amp_is_enabled('amp_post_show_author') ?> value="true"></label>
								</div>
							</td>
							<td scope="row">
								<b>Pages</b><br><br>
								<div class="checkbox distance"><label>
									<input type="checkbox" <?php echo wp_amp_is_enabled('amp_page_show_author') ?> value="true"></label>
								</div>
							</td>
						</tr>
					</table>
					
	            </td>
			</tr>
			<tr>
				<th scope="row"><br><div class="disable-labels">Show Date:</div></th>
				<td>

					<table class="table" width="18%">
						<tr>
							<td><div class="checkbox distance"><label>
								<input type="checkbox" <?php echo wp_amp_is_enabled('amp_post_show_date') ?> value="true"></label></div>
							</td>
							<td><div class="checkbox distance"><label>
								<input type="checkbox" <?php echo wp_amp_is_enabled('amp_page_show_date') ?> value="true"></label></div>
							</td>
						</tr>
					</table>
					
	            </td>
			</tr>
			<tr>
				<th scope="row"><br><div class="disable-labels">Show Category:</div></th>
				<td>

					<table class="table" width="18%">
						<tr>
							<td><div class="checkbox distance"><label>
								<input type="checkbox" <?php echo wp_amp_is_enabled('amp_post_show_category') ?> value="true"></label></div>
							</td>
						</tr>
					</table>
					
	            </td>
			</tr>
			<tr>
				<th scope="row">&nbsp;</th>
				<td>
		          &nbsp;&nbsp;<button type="submit" class="button button-primary">Save</button>
	            </td>
			</tr>
		</tbody>
	</table>
	
</form>