
jQuery(document).ready(function($){

	$(".choose-color").spectrum({
	    preferredFormat: "hex"
	});

	var settingsFormValidator = $('#amp-settings-form').parsley();

	var validateSettingsForm = function(){
		settingsFormValidator.validate();
		if(false === settingsFormValidator.isValid()){
			return false;
		}
	};

	var settingsFormOptions = {
		beforeSerialize : validateSettingsForm,
		url : ajaxurl + '?action=save_wp_amplifier_page_settings',
		success : function(response){
			var html = '<div class="notice is-dismissible updated"><p>Your configurations are updated successfully</p></div>';
			$('.response-msg').html(html);
			$('img.site-icon').attr({
				src : response.logo_url,
				width: response.width,
				height : response.height
			});
			$('.cancel-amp-logo').click();
			$("html, body").animate({
	            scrollTop: 0
	        }, 600);
		}
	};

	var checkForFile = function(){
		csvUploadValidator.validate();
		if(false === csvUploadValidator.isValid()){
			return false;
		}
	};
	

	$('#amp_page_logo').change()

	$('#amp-settings-form').ajaxForm(settingsFormOptions);

	$('.remove-amp-logo').click(function(evt){
		evt.preventDefault();
		$('.upload-amp-logo').show().prev().hide();
	});

	$('.cancel-amp-logo').click(function(evt){
		evt.preventDefault();
		$('.upload-amp-logo').hide().prev().show();
	});

	$('.lactivate-plugin').click(function (evt) {
		evt.preventDefault();
		var v = $('#activation-form').parsley();
		v.validate();
		if (!v.isValid()) {
			return;
		}
		var key = $('#activation_key').val();
		var email = $('#activation_email').val();
		var _this = this;
		$('#response-msg').html('');
		$(_this).text('Activating...');
		$.post(ajaxurl, {
			action: 'wp_amplifier_activate_plugin',
			activation_key: key,
			activation_email: email
		}, function (resp) {
			if (resp.success === true) {
				$(_this).text('Activated successfully. Relading page... Please wait...');
				window.location.reload();
			}
			else {
				$('#response-msg').html('<div class="error settings-error notice is-dismissible"><p>' + resp.data.message + '</p></div>');
				$(_this).text('Activate');
			}
		})
	})

});