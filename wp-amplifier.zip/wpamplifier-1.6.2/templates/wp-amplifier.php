<!doctype html>
<html amp>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
	<link href="https://fonts.googleapis.com/css?family=Merriweather:400,400italic,700,700italic|Open+Sans:400,700,400italic,700italic" rel="stylesheet" type="text/css">
	<?php do_action( 'amp_post_template_head', $this ); ?>
	
	<style amp-custom>
	<?php $this->load_parts( array( 'style' ) ); ?>
	<?php do_action( 'amp_post_template_css', $this ); ?>
	nav.amp-wp-title-bar{
		background-color: <?php echo $this->get('navigation_bar_color'); ?>;
	}
	nav.amp-wp-title-bar .site-icon{
		border-radius:0;
		margin: 0;
	}
	.clearfix{
		clear: both;
	}
	.contact-details{
		margin: 0;
		float: right;
		line-height: <?php echo $this->get('amp_logo_height'); ?>px;
		color: <?php echo $this->get('amp_navigation_text_color'); ?>;
	}
	</style>
</head>
<body>
<nav class="amp-wp-title-bar">
	<div>
		<a href="<?php echo esc_url( $this->get( 'home_url' ) ); ?>">
			<?php $site_icon_url = $this->get( 'site_icon_url' ); ?>
			<?php if ( $site_icon_url ) : ?>
				<amp-img src="<?php echo esc_url( $site_icon_url ); ?>" 
					width="<?php echo $this->get('amp_logo_width'); ?>" 
					height="<?php echo $this->get('amp_logo_height'); ?>" 
					class="site-icon"></amp-img>
			<?php else : ?>
				<?php echo esc_html( $this->get( 'blog_name' ) ); ?>
			<?php endif; ?>
			<h2 class="contact-details">
				<?php echo esc_html( $this->get( 'amp_contact_details' ) ); ?>
			</h2>
			<div class="clearfix"></div>
		</a>
	</div>
</nav>
<div class="amp-wp-content">
	<h1 class="amp-wp-title"><?php echo esc_html( $this->get( 'post_title' ) ); ?></h1>
	<ul class="amp-wp-meta">
		<?php $this->load_parts( apply_filters( 'amp_post_template_meta_parts', array( 'meta-author', 'meta-time', 'meta-taxonomy' ), $this->get('post') ) ); ?>
	</ul>
	<?php echo $this->get( 'post_amp_content' ); // amphtml content; no kses ?>
</div>
<?php do_action( 'amp_post_template_footer', $this ); ?>
</body>
</html>
